from rest_framework import serializers

from .models import Project, Category

class ProjectSerializer(serializers.ModelSerializer):
    members = serializers.SerializerMethodField()
    category = serializers.SerializerMethodField()
    class Meta:
        model = Project
        fields = [
            'title', 'description',
            'members', 'category',
            'created_at', 'updated_at',
        ]

    def get_members(self, obj):
        return [i.id for i in obj.members.all()]

    def get_category(self, obj):
        return obj.category.name
