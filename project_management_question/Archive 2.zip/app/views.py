from rest_framework.generics import ListAPIView

from rest_framework.permissions import IsAuthenticated

from .models import Project
from .serializers import ProjectSerializer

class ProjectListView(ListAPIView):
    def filter_queryset(self, queryset):
        return super().filter_queryset(queryset).filter(
            members__person=self.request.user
        )

    permission_classes = [IsAuthenticated]
    queryset = Project.objects.prefetch_related('members').order_by('-updated_at')
    serializer_class = ProjectSerializer
